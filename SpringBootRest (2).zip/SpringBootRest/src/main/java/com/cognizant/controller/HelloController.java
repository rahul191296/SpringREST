package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("hello")
public class HelloController {
	@GetMapping("sayHello/{name}")
	public String sayHello(@PathVariable("name")String name){
		return "Hello "+name;
	}
	@GetMapping("names")
	public List<String> names(){
		List<String> names=new ArrayList<String>();
		names.add("Sabbir");
		names.add("Amit");
		names.add("Sumeet");
		names.add("Chirag");
		
		return names;
		
	}

}
