package com.cognizant.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StudentModel;
@Service
public class StudentServiceImpl implements StudentService{
	
	static List<StudentModel> studentsList=new ArrayList<StudentModel>();
	static{
		
		StudentModel student1=new StudentModel();
		student1.setRollNo(1001);
		student1.setFirstName("Rahul");
		student1.setLastName("Chauhan");
		student1.setAge(21);
		
		StudentModel student2=new StudentModel();
		student2.setRollNo(1002);
		student2.setFirstName("Amit");
		student2.setLastName("Gupta");
		student2.setAge(22);
		
		StudentModel student3=new StudentModel();
		student3.setRollNo(1003);
		student3.setFirstName("Priya");
		student3.setLastName("Shah");
		student3.setAge(20);
		
		studentsList.add(student1);
		studentsList.add(student2);
		studentsList.add(student3);
		
		
	}

	public List<StudentModel> getAllStudents() {
		// TODO Auto-generated method stub
		return studentsList;
	}

	public StudentModel getStudentByRollNo(int rollNo) {
		// TODO Auto-generated method stub
		StudentModel studentByRollNo=new StudentModel();
		for(StudentModel student:studentsList){
			if(student.getRollNo()==rollNo){
				studentByRollNo=student;
			}
		}
		return studentByRollNo;
	}

	public boolean persistStudentModel(StudentModel student) {
		// TODO Auto-generated method stub
		return studentsList.add(student);
	}

	public boolean updateStudentModelAge(StudentModel newStudent) {
		// TODO Auto-generated method stub
		boolean result=false;
		
	
		for(Iterator<StudentModel> iterator=studentsList.iterator();iterator.hasNext();){
			
			StudentModel student=iterator.next();
			if(student.getRollNo()==newStudent.getRollNo()){
				student.setAge(newStudent.getAge());
				result=true;
			}else{
result=false;	
}
			
			
		}
		
		if(!result){
			studentsList.add(newStudent);
		}
		
		return result;
	}

	public boolean deleteStudentModel(int rollNo) {
		// TODO Auto-generated method stub
		return false;
	}

}
