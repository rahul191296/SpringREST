package com.cognizant.model;

import java.io.Serializable;

public class StudentModel implements Serializable {
	
	public StudentModel(){}
	
	public StudentModel(int rollNo, String firstName, String lastName, int age) {
		super();
		this.rollNo = rollNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}

	private int rollNo;
	private String firstName;
	private String lastName;
	private int age;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "StudentModel [rollNo=" + rollNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", age=" + age + "]";
	}
	
	

}
