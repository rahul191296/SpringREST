package com.cognizant.client;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cognizant.model.StudentModel;

public class UpdateStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       RestTemplate template=new RestTemplate();
			
			HttpHeaders headers=new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			
			StudentModel studentmodel=new StudentModel();
			studentmodel.setRollNo(1008);
			studentmodel.setFirstName("Rakesh");
			studentmodel.setLastName("Mehta");
			studentmodel.setAge(45);
			
			HttpEntity<StudentModel> request=
					new HttpEntity<StudentModel>(studentmodel,headers);
			
			String url="http://localhost:8081/student/updatestudent";
			template.put(url, request);
	}

}
